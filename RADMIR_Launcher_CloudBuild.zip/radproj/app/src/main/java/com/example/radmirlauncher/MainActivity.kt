package com.example.radmirlauncher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val root = FrameLayout(this)
  root.setBackgroundResource(R.drawable.background)
  val shade = FrameLayout(this); shade.setBackgroundColor(0x99000000.toInt()); root.addView(shade, FrameLayout.LayoutParams(-1,-1))
  val col = LinearLayout(this); col.orientation=LinearLayout.VERTICAL; col.gravity=Gravity.CENTER; col.setPadding(32,32,32,32)
  root.addView(col, FrameLayout.LayoutParams(-1,-1))
  val title=TextView(this); title.text="RADMIR"; title.textSize=38f; title.setTextColor(Color.WHITE); title.typeface=Typeface.DEFAULT_BOLD; title.gravity=Gravity.CENTER
  col.addView(title)
  val sub=TextView(this); sub.text="MOBILE LAUNCHER"; sub.textSize=15f; sub.setTextColor(0xFFD9B7FF.toInt()); sub.gravity=Gravity.CENTER; col.addView(sub)
  val spacer=Space(this); col.addView(spacer,LinearLayout.LayoutParams(1,0,1f))
  val ip=TextView(this); ip.text="SERVER  •  80.242.59.112:5309"; ip.setTextColor(Color.WHITE); ip.textSize=16f; ip.gravity=Gravity.CENTER; col.addView(ip)
  val play=Button(this); play.text="ИГРАТЬ"; play.textSize=20f; play.setTextColor(Color.WHITE); play.setBackgroundColor(0xFF7B2DCC.toInt()); col.addView(play,LinearLayout.LayoutParams(-1,64))
  play.setOnClickListener { val launch=intentForPackage("com.hassle.online"); if(launch!=null) startActivity(launch) else Toast.makeText(this,"Игровой клиент не установлен. Установите совместимый клиент отдельно.",Toast.LENGTH_LONG).show() }
  val info=TextView(this); info.text="Кнопка пока открывает установленный клиент. Подключение к серверу не встроено."; info.textSize=12f; info.setTextColor(Color.WHITE); info.gravity=Gravity.CENTER; info.setPadding(0,18,0,0); col.addView(info)
  setContentView(root)
 }
 private fun intentForPackage(pkg:String):Intent? { return packageManager.getLaunchIntentForPackage(pkg) }
}
